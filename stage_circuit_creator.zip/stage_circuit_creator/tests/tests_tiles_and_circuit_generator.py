import unittest
import os
import pyvista as pv
from PIL import Image
import modules.tiles_generator as md
import modules.circuit_generator as cg

class TestPyVistaScreenshot(unittest.TestCase):
    """
    Unit test to verify that PyVista can render a 3D object (Box) and save a screenshot correctly.
    """

    def test_pyvista_screenshot(self):
        """
        Tests whether PyVista can generate a screenshot with the correct dimensions and save it to the specified location.
        """
        self.screenshot_path = 'test.png'
        
        # Create a PyVista object and set up the plotter
        sphere = pv.Box()
        plotter = pv.Plotter(off_screen=True, window_size=(900, 900))
        plotter.add_mesh(sphere, color="black", opacity=1)
        plotter.view_xy()
        plotter.zoom_camera("tight")

        # Take a screenshot and save it
        plotter.screenshot(filename=self.screenshot_path, transparent_background=True)

        # Verify the screenshot was saved
        self.assertTrue(os.path.isfile(self.screenshot_path), "Screenshot file was not created")

        # Verify the dimensions of the saved image
        if os.path.isfile(self.screenshot_path):
            with Image.open(self.screenshot_path) as img:
                width, height = img.size
                self.assertEqual(width, 900, "Screenshot width is not 900 pixels")
                self.assertEqual(height, 900, "Screenshot height is not 900 pixels")

            # Clean up the test file
            os.remove(self.screenshot_path)

class TestRenderingTiles(unittest.TestCase):
    """
    Unit test to ensure that tiles and circuits are generated correctly.
    """

    def test_rendering_tiles(self):
        """
        Tests the generation of tiles and circuits, verifies the output images, and checks dimensions.
        Also ensures that the number of circuit configurations matches the number of generated circuit images.
        """
        # Define paths for input and output
        self.output_directory = os.path.join(os.getcwd(), 'test_output')
        
        # Run the tiles generator process
        self.obj_directory=os.path.join(os.getcwd(), 'obj_folders')
        md.process_folders(obj_directory=self.obj_directory, output_directory=self.output_directory)
        
        # Check if output directory exists
        self.assertTrue(os.path.exists(self.output_directory), "Output directory was not created")
        
        # Check for exactly 16 generated PNG files
        obj_files = [f for f in os.listdir(self.obj_directory)]
        png_files = [f for f in os.listdir(self.output_directory) if f.endswith('.png')]
        self.assertEqual(len(png_files), len(obj_files), "There should be the same tiles as obj folders!.")

        # Verify the dimensions of each generated tile
        for file_name in png_files:
            file_path = os.path.join(self.output_directory, file_name)
            with Image.open(file_path) as img:
                self.assertEqual(img.size, (900, 900), f"File {file_name} is not 900x900 pixels.")
        
        # Define paths for circuit text and output directories
        self.text_directory = os.path.join(os.getcwd(), 'circuit_conf_txt')
        self.circuit_directory = os.path.join(os.getcwd(), 'circuits_png')
        
        # Run the circuit generator
        cg.main(self.output_directory, self.text_directory)

        # Ensure the 'circuits_png' directory was created
        if not os.path.isdir(self.circuit_directory):
            self.fail(f"The directory for circuits '{self.circuit_directory}' was not created")

        # Get the number of text files (circuit configurations)
        txt_files = [f for f in os.listdir(self.text_directory) if f.endswith('.txt')]

        # Get the number of generated circuit images
        circuit_images = [f for f in os.listdir(self.circuit_directory) if f.endswith('.png')]

        # Assert that the number of text files matches the number of generated circuit images
        self.assertEqual(len(txt_files), len(circuit_images), 
                        f"The number of circuit configurations ({len(txt_files)}) does not match the number of generated circuit images ({len(circuit_images)}).")

        # Clean up generated files after the test
        for file in os.listdir(self.output_directory):
            os.remove(os.path.join(self.output_directory, file))
        os.rmdir(self.output_directory)

        for circuit in os.listdir(self.circuit_directory):
            os.remove(os.path.join(self.circuit_directory, circuit))
        os.rmdir(self.circuit_directory)


if __name__ == "__main__":
    unittest.main()

# Stage's circuit creator

The aim of this project is to create custom circuits for the Stage Simulator using the 1:10 scale Road Modules designed by Marcel Ullersperger.  

![Test tiles](readme_images/test_tiles.png)


## Requirements

- PyVista
- NumPy
- OpenCV
- PIL (Pillow)

You can install the required Python packages using `pip`. Get on the root foolder of the project and open a terminal inside `Chimera`. 

```bash
cd stage_circuit_creator
pip install -r requirements.txt
```

## Tests

To run the tests to check the correct working of the program, execute in the terminal inside the `stage_circuit_creator` project folder:

```bash
python3 -m unittest tests/tests_tiles_and_circuit_generator.py 
```


## Usage

### Rendering tiles 

 The Python script `tiles_generator.py` renders the 1:10 scale road modules from `.obj` files into `.png` images using PyVista library (https://docs.pyvista.org/). 
 
 It processes all tiles with the desired resolution. 900 pixels is the standard value because it provides enough resolution and it matches the scale *1:1* pixel to milimeter.

 It is required that the parts contain the colour they have to be painted in the **filename**

![Test tiles](readme_images/size_tile.png)

To render the tiles it is necessary again to open a terminal in the **Chimera** directory and run the following bash command. Without indicating any argument, the script will create all the tiles with a resolution of 900 px, create a directory "rendered_tiles_{resolution}/" where the tiles will be saved.

To run default configuration just use:

```bash
cd stage_circuit_creator
python3 modules/tiles_generator.py 
```

Otherwise the following arguments can be specified and changed:

        obj_directory (str): The path to the parent directory containing subfolders with .obj files.
        resolution (int):       Desired resolution for the rendered circuit tiles.
        output_directory (str): The path to the directory where output images will be saved.

```bash
python modules/tiles_generator.py --obj_directory <custom_obj_dir> --resolution <custom_resolution> --output_directory <custom_output_dir>
```

`vtkOBJReader.cxx:215   WARN| vtkOBJReader (0x64af0bcd43f0): unexpected data at end of line in OBJ file L.2` warning may be shown, but it is no problem. Now the tiles should have been generated.

The rendered_tiles_900 directory may now appear in your workspace containing the .png tiles.

## Load and generate circuits

The script `circuit_generator.py` loads all the tiles while considering all possible orientations and saves them to a dictionary. Tiles are then concatenated to create custom tracks that are defined in `/circuit_conf_txt`. 

To generate the existent circuits, with the terminal launched inside `stage_circuit_creator` Chimera's workspace with default conf:

```bash
cd stage_circuit_creator
python3 modules/circuit_generator.py
```

Otherwise:

```bash
python3 modules/generate_circuits.py --rendered_tiles_dir <path/to/tiles> --circuit_txt_dir </path/to/circuit_conf_txt>
```

The resulting circuits images may now appear in `/circuits_png`. The filenames will be the .txt file name itself and the equivalence in meters depending the amount of tiles used will be also included, information that will be needed to load them in Stage sim.

## Creating circuits

To create a circuit, you need to provide a configuration file in plain text format. This file describes the arrangement of tiles to generate the desired circuit layout.

#### Text File Structure

Each line in the text file represents a row of tiles in the circuit. Here’s a breakdown of how to define the circuit configuration:

1. Define row and tile types. For every row, allowed tile names are the following:

```
        -two_lanes_separated_vertical
        -two_lanes_guideline1_vertical
        -two_lanes_guideline2_vertical
        -two_lanes_to_1_lane_vertical
        -x_junction 
        -t_junction_leftwards
        -one_lane_to_LtoR_vertical
        -one_lane_to_RToL_vertical
        -one_lane_vertical
        -one_to_two_lanes_vertical
        -soft_curve_1_top_right
        -soft_curve_2_top_right
        -soft_curve_3_top_right
        -soft_curve_4_top_right
        -curve_90_top_right
        -black
```

    There is a pattern regarding tilenames: first part of the name defines the tile and the right part defines the orientation. Straight tiles only have horizontal and vertical orientation.

    Curves can have up to 4 orientations. In this case, top/bottom-rigth/left orientation is used, based on the positions they would fit in an oval-shaped circuit. 

    T-Junctions orientation is indicated by leftwards, rightwards, upwards or down, depending where the baselane is pointing. 
    **Not** writing porperly the tilename will result in a *key error*.
    

2. For every **row**, write the tiles separated by a **comma**. What it is being done is creating a 2D array that represents the circuit. One must think of it as a grid. Every element in the array is what will be displayed in the matrix. All rows **must** have the same **length**.
    
    -row: tilename_orientation, tilename2_orientation...

    -row: tilename3_orientation, tile4_orientation...
    
 Rows can also be defined by indicating tiles and repeating them N times. Use `tiles` and `repeat`to indicate the tiles and times to be repeated. For instance:

    tiles: two_lanes_guideline2_horizontal, two_lanes_guideline1_horizontal
    repeat: 5

    This creates a discontinuous lane of 10 tiles lentgh.

 Bear in mind that the 30 degree turn tile is formed with 4 different tiles. See circuit examples to better understand.

3.  Black tile is used for padding.

    Stage simulator creates a white background when the map ends. It is useful to use black tiles to mitigate the impact of white in sensors.

#### Circuit examples

For instance, the following lines create a oval-shaped circuit wih smooth turns and padding. 
Two padding rows are added and the first and last tiles of every row are black to achieve the black surroundings. Pay attetnion to the positions of the soft_curve tiles.

```
tiles: black
repeat: 8
row: black, soft_curve_2_top_left, soft_curve_1_top_left, two_lanes_separated_horizontal, two_lanes_separated_horizontal, soft_curve_3_top_right, soft_curve_2_top_right, black
row: black, soft_curve_3_top_left, soft_curve_4_top_left, black, black, soft_curve_4_top_right, soft_curve_1_top_right, black
row: black, two_lanes_separated_vertical, black, black, black, black, two_lanes_separated_vertical, black
row: black, soft_curve_1_bottom_left, soft_curve_4_bottom_left, black, black, soft_curve_4_bottom_right, soft_curve_3_bottom_right, black
row: black, soft_curve_2_bottom_left, soft_curve_3_bottom_left, two_lanes_separated_horizontal, two_lanes_separated_horizontal, soft_curve_1_bottom_right, soft_curve_2_bottom_right, black
tiles: black
repeat: 8
```

The following circuit creates a sinusoidal-shaped with lane reduction:

```
# circuit_name = "2to1Lane"
row: two_lanes_guideline2_horizontal,two_lanes_guideline1_horizontal,two_lanes_to_1_lane_horizontal,one_lane_horizontal,one_lane_to_RToL_horizontal, one_lane_to_LtoR_horizontal, one_to_two_lanes_horizontal, two_lanes_guideline2_horizontal
```

### Resizing images

-resize_image.py: is a helper file to resize an image in case is needed.
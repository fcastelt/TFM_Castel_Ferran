from setuptools import setup, find_packages

package_name = 'stage_circuit_creator'
submodules = 'stage_circuit_creator/modules'

setup(
    name=package_name,
    version="0.1.0",
    packages=[package_name, submodules],
    install_requires=[
        "pyvista",  # Add any other dependencies here
        "numpy",
        "opencv-python",
        "Pillow",
    ],
    description="A project for generating circuits for the Stage Simulator.",
    author="Your Name",
    author_email="your.email@example.com"  # Optional, add if you have a project URL
)


from chimera_custom_interfaces.msg import PoseWithLanePoints
from rclpy.node import Node
import numpy as np
import rclpy
class LanePointsSubscriber(Node):
    def __init__(self):
        super().__init__('lane_points_subscriber')

        # Subscription to the LanePointsWithPose topic
        self.create_subscription(
            PoseWithLanePoints,
            '/lane_points',
            self.lane_points_callback,
            10
        )

    def lane_points_callback(self, msg):
        # Unpack the Pose
        try:
            robot_pose = msg.pose
            self.get_logger().info(f"Robot Pose: x={robot_pose.position.x}, y={robot_pose.position.y}, z={robot_pose.position.z}")
            
            # Unpack and process lane points
            self.left_lane_points = np.array(msg.left_lane_points).reshape(-1, 2)*-1
            self.right_lane_points = np.array(msg.right_lane_points).reshape(-1, 2)*-1
            self.center_lane_points = np.array(msg.center_lane_points).reshape(-1, 2)*-1
            self.neighbour_left_lane_points = np.array(msg.neighbour_left_lane_points).reshape(-1, 2)*-1
            self.neighbour_right_lane_points = np.array(msg.neighbour_center_right_lane_points).reshape(-1, 2)*-1
            self.neighbour_center_lane_points = np.array(msg.neighbour_right_lane_points).reshape(-1, 2)*-1
        except Exception as e: 
            self.get_logger().error(f"Error processing message: {e}")

def main(args=None):
    rclpy.init(args=args)
    subscriber = LanePointsSubscriber()
    rclpy.spin(subscriber)
    subscriber.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

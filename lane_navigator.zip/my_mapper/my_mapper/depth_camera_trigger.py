import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from std_srvs.srv import Trigger  # ROS2 built-in Trigger service type
import numpy as np

class DepthCameraTriggerNode(Node):
    def __init__(self):
        super().__init__('depth_camera_trigger')
        
        # Subscriber for depth camera image
        self.depth_sub = self.create_subscription(
            Image,
            '/depth0',  # Replace with your depth camera topic
            self.depth_callback,
            10
        )

        self.depth_pub = self.create_publisher(
            Image,
            '/depth_interest',
            10
        )
        
        # Service client for the trigger service
        self.trigger_client = self.create_client(Trigger, '/trigger_change_event')
        while not self.trigger_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('/trigger_change_event service not available, waiting...')

        self.bridge = CvBridge()
        self.obstacle_threshold = 2.75  # Trigger if an obstacle is closer than 3 meters
        self.saved = False  # Flag to save only one message
        self.get_logger().info("DepthCameraTriggerNode has started.")

    def depth_callback(self, msg):
        try:
            # Convert ROS Image message to a CV2 image
            depth_image = self.bridge.imgmsg_to_cv2(msg, desired_encoding="passthrough")
            # Example: Analyze the central region of the depth image
            height, width = depth_image.shape
            center_x, center_y = width // 2, height // 2
            region_of_interest = depth_image[center_y-10:center_y+10, center_x-10:center_x+10]
            # region_image = self.bridge.cv2_to_imgmsg(region_of_interest, encoding="passthrough")
            # self.depth_pub.publish(region_image)
            # # Save to CSV only once
            # if not self.saved:
            #     self.save_to_csv(region_of_interest)
            #     self.saved = True
            # Calculate the minimum distance in the region
            min_distance = region_of_interest.min()
            
            if min_distance < self.obstacle_threshold:
                self.get_logger().info(f"Obstacle detected at {min_distance:.2f} meters. Calling trigger service!")
                self.call_trigger_service()
        except Exception as e:
            self.get_logger().error(f"Error processing depth image: {e}")

    def save_to_csv(self, depth_image):
        try:
            # Save the depth image as a CSV file
            file_path = 'my_logs/depth_image.csv'  # Update the path if needed
            np.savetxt(file_path, depth_image, delimiter=",")
            self.get_logger().info(f"Depth image saved to {file_path}")
        except Exception as e:
            self.get_logger().error(f"Failed to save depth image to CSV: {e}")

    def call_trigger_service(self):
        # Create a service request
        request = Trigger.Request()

        # Call the service
        future = self.trigger_client.call_async(request)

        # Add a callback to handle the response
        future.add_done_callback(self.handle_service_response)

    def handle_service_response(self, future):
        try:
            response = future.result()
            if response.success:
                self.get_logger().info(f"Trigger service succeeded: {response.message}")
            else:
                self.get_logger().warn(f"Trigger service failed: {response.message}")
        except Exception as e:
            self.get_logger().error(f"Failed to call trigger service: {e}")

def main(args=None):
    rclpy.init(args=args)
    node = DepthCameraTriggerNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

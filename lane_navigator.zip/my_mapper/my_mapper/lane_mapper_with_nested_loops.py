import numpy as np
import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import Header, Float32MultiArray, Int8MultiArray
import tf2_ros
from tf2_ros import TransformListener, Buffer
import tf_transformations
from rclpy.qos import QoSProfile, DurabilityPolicy
import time
import csv
from sensor_msgs.msg import PointCloud2 
import sensor_msgs_py.point_cloud2 as pc2 

class DynamicMapNode(Node):
    def __init__(self):
        super().__init__('dynamic_map_node')

        # Occupancy grid parameter
        self.left_lane_updated = False
        self.right_lane_updated = False
        self.neighbour_left_lane_updated = False
        self.neighbour_right_lane_updated = False

        qos_profile = QoSProfile(depth=10, durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.map_resolution = 0.01  # Resolution in meters per cell
        self.map_width = int(15.0 / self.map_resolution)  # 15 meters
        self.map_height = int(10.0 / self.map_resolution)  # 10 meters
        self.occupancy_grid = np.full((self.map_height, self.map_width), -1, dtype=np.int8)

        # Publisher for the occupancy grid
        self.map_pub = self.create_publisher(OccupancyGrid, '/map', qos_profile)

        # TF listener to track the car's position and orientation
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Timer to update the map
        self.create_timer(0.75, self.update_map)
        self.create_timer(0.75, self.update_car_position)

        # Subscriptions for lane points
        self.left_lane_sub = self.create_subscription(Float32MultiArray, "left_lane_points", self.left_lane_callback, 10)
        self.right_lane_sub = self.create_subscription(Float32MultiArray, "right_lane_points", self.right_lane_callback, 10)
        self.neighbour_left_lane_sub = self.create_subscription(Float32MultiArray, "neighbour_left_lane_points", self.neighbour_left_lane_callback, 10)
        self.neighbour_right_lane_sub = self.create_subscription(Float32MultiArray, "neighbour_right_lane_points", self.neighbour_right_lane_callback, 10)
        self.center_lane_sub =  self.create_subscription(Float32MultiArray, "center_lane_points", self.center_lane_callback, 10)


        self.lane_info_sub = self.create_subscription(Int8MultiArray, "lane_info", self.lane_info_callback, 10)

        self.right_lane_points = []
        self.left_lane_points = []
        self.neighbour_right_lane_points = []
        self.neighbour_left_lane_points = []
        self.center_lane_points = []
        # Camera offsets
        self.camera_offset_x = 1.65 # FORWARD
        self.camera_offset_y = 1.5  # lateral

        self.flag_lane_found = 0

        self.car_x = None
        self.car_y = None
        self.car_yaw = None

        self.new_pose_received = False
        self.new_lane_points_received = False


    def lane_info_callback(self, msg):
        self.flag_lane_found = msg.data[0]
        self.course = msg.data[1]
        self.flag_dashed = msg.data[2]
        #self.update_map()

    def center_lane_callback(self, msg):
        """Callback to receive center lane points."""
        self.center_lane_points = np.array(msg.data).reshape(-1, 2)*-1
        #self.center_lane_updated = True



    def left_lane_callback(self, msg):
        """Callback to receive left lane points."""
        self.left_lane_points = np.array(msg.data).reshape(-1, 2)*-1
        self.new_lane_points_received = True
        
        # self.left_lane_points = np.array(msg.data).reshape(-1, 2)
        #self.get_logger().info(f"Received left lane points: {self.neighbour_left_lane_points}")
        #self.save_lane_points_to_csv() 

    def right_lane_callback(self, msg):
        """Callback to receive right lane points."""
        self.right_lane_points = np.array(msg.data).reshape(-1, 2)*-1
        self.right_lane_updated = True
        #self.get_logger().info(f"Received right lane points: {self.right_lane_points}")
    
    def neighbour_left_lane_callback(self, msg):
        """Callback to receive left lane points."""
        self.neighbour_left_lane_points = np.array(msg.data).reshape(-1, 2)*-1
        self.neighbour_left_lane_updated = True
        #self.get_logger().info(f"Received left lane points: {self.left_lane_points}")

    def neighbour_right_lane_callback(self, msg):
        """Callback to receive right lane points."""
        self.neighbour_right_lane_points = np.array(msg.data).reshape(-1, 2)*-1
        self.neighbour_right_lane_updated = True
        #self.get_logger().info(f"Received right lane points: {self.right_lane_points}")
    # def check_and_update_map(self):
    #     if (self.left_lane_updated and self.right_lane_updated):
    #         self.update_map()
    #         # Reset flags after map update
    #         self.left_lane_updated = False
    #         self.right_lane_updated = False
    #         self.neighbo98zur_left_lane_updated = False
    #         self.neighbour_right_lane_updated = False

    def update_car_position(self):
        try:
            # Get the latest transform
            transform = self.tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time())
            self.car_x = transform.transform.translation.x
            self.car_y = transform.transform.translation.y
            rotation_quat = [
                transform.transform.rotation.x,
                transform.transform.rotation.y,
                transform.transform.rotation.z,
                transform.transform.rotation.w
            ]
            _, _, self.car_yaw = tf_transformations.euler_from_quaternion(rotation_quat)
            self.new_pose_received = True
            #self.get_logger().info(f"Car position from transform is: ({self.car_x:.2f}, {self.car_y:.2f}), Car yaw: {self.car_yaw:.2f}") 
        except Exception as e:
            self.get_logger().warn(f"Could not get transform: {e}")
        
    def update_map(self):
        if self.flag_lane_found != 1:
            self.get_logger().info("Lane not found, stopping map update.")
            return  # Stop updating if lanes are not found
        
        if not (self.new_pose_received and self.new_lane_points_received):
            self.get_logger().info("self new pose received value is : " + str(self.new_pose_received) + " and self new lane points received value is : " + str(self.new_lane_points_received))
            return
        
        car_x = self.car_x
        car_y = self.car_y
        car_yaw = self.car_yaw
        self.new_pose_received = False
        self.new_lane_points_received = False


        # Select lanes to plot based on flag_dashed
        if self.flag_dashed == -1:  ## CHIMERA IS AT LEFT LANE
                left_lane_rotated = self.plot_polyline(car_x, car_y, car_yaw, self.left_lane_points, is_left_lane=True)
                right_lane_rotated = self.plot_polyline(car_x, car_y, car_yaw, self.neighbour_right_lane_points, is_left_lane=False)
        elif self.flag_dashed == 0: ## NO LANE
                left_lane_rotated = self.plot_polyline(car_x, car_y, car_yaw, self.left_lane_points, is_left_lane=True)
                right_lane_rotated = self.plot_polyline(car_x, car_y, car_yaw, self.right_lane_points, is_left_lane=False)
        elif self.flag_dashed == 1: ## CHIMERA IS AT RIGHT LANE
                left_lane_rotated = self.plot_polyline(car_x, car_y, car_yaw, self.neighbour_left_lane_points , is_left_lane=True)
                right_lane_rotated = self.plot_polyline(car_x, car_y, car_yaw, self.right_lane_points, is_left_lane=False)

        # Fill between lanes if both are available
        if left_lane_rotated and right_lane_rotated:
            self.fill_between_lanes(left_lane_rotated, right_lane_rotated)
        # Handle center lane points, always plot as free space (0)
        #self.plot_polyline(car_x, car_y, car_yaw, self.center_lane_points, is_left_lane=False)

        #Publish the updated map
        self.publish_map()

       # except Exception as e:
            #self.get_logger().warn(f"Could not get transform: {e}")

            
    def fill_between_lanes(self, left_points, right_points, padding=1):
        """Marks cells between left and right lane points as free space with optional padding."""
        for (lx, ly), (rx, ry) in zip(left_points, right_points):
            # Interpolate points between the left and right lanes
            y_range = np.linspace(lx, rx, num=20)
            x_range = np.linspace(ly, ry, num=20)

            for i, (x, y) in enumerate(zip(x_range, y_range)):
                if i < 1 or i >= len(x_range) - 1:
                    continue
                # Convert real-world coordinates to grid indices
                grid_x = int((y / self.map_resolution) + self.map_width // 2)
                grid_y = int((x / self.map_resolution) + self.map_height // 2)

                # Add padding around each point
                for dx in range(-padding, padding + 1):
                    for dy in range(-padding, padding + 1):
                        adj_x = grid_x + dx
                        adj_y = grid_y + dy

                        # Check if the padded cell is within the bounds of the occupancy grid
                        if 0 <= adj_x < self.map_width and 0 <= adj_y < self.map_height:
                            # Only update cells with the default value of -1
                            #if self.occupancy_grid[adj_y, adj_x] == -1:
                            self.occupancy_grid[adj_y, adj_x] = 0  # Mark as free space


    def plot_polyline(self, car_x, car_y, car_yaw, points, is_left_lane=True):
        """
        Optimized method to plot a polyline on the occupancy grid with selective padding.

        Parameters:
        - car_x, car_y: Robot's position in the map.
        - car_yaw: Robot's yaw angle in radians.
        - points: List of lane points in the camera frame (pixel coordinates scaled to meters).
        - is_left_lane: Boolean indicating whether the lane is on the left.
        """
        # Adjust points for camera offsets
        for point in points:
            point[0] += self.camera_offset_y  # Adjust y-coordinate
            point[1] += self.camera_offset_x  # Adjust x-coordinate

        # Interpolate and transform points
        rotated_points = []
        for i in range(len(points) - 1):
            start, end = points[i], points[i + 1]

            # Perform linear interpolation between consecutive points
            x_range = [start[1] + (end[1] - start[1]) * t / 10 for t in range(10)]
            y_range = [start[0] + (end[0] - start[0]) * t / 10 for t in range(10)]

            for sx, sy in zip(x_range, y_range):
                rotated_x = car_x + sx * np.cos(car_yaw) - sy * np.sin(car_yaw)
                rotated_y = car_y + sx * np.sin(car_yaw) + sy * np.cos(car_yaw)
                rotated_points.append((rotated_x, rotated_y))

                # Map rotated points onto the occupancy grid
                grid_x = int((rotated_x / self.map_resolution) + self.map_width // 2)
                grid_y = int((rotated_y / self.map_resolution) + self.map_height // 2)

                if 0 <= grid_x < self.map_width and 0 <= grid_y < self.map_height:
                    # Apply selective padding for left or right lanes
                    padding_range = range(-3, 0) if is_left_lane else range(0, 3)
                    for dx in padding_range:
                        for dy in range(-1, 2):
                            adj_x, adj_y = grid_x + dx, grid_y + dy
                            if 0 <= adj_x < self.map_width and 0 <= adj_y < self.map_height:
                                self.occupancy_grid[adj_y][adj_x] = 100  # Mark as occupied

        return rotated_points

        
    def save_lane_points_to_csv(self):
        """Save all lane points to a CSV file."""
        file_name = "my_logs/lane_points.csv"
        with open(file_name, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["Lane Type", "X", "Y"])  # Header

            # Save left lane points
            for point in self.left_lane_points:
                writer.writerow(["Left", point[0], point[1]])

            # Save right lane points
            for point in self.right_lane_points:
                writer.writerow(["Right", point[0], point[1]])

            # Save neighbour left lane points
            for point in self.neighbour_left_lane_points:
                writer.writerow(["Neighbour Left", point[0], point[1]])

            # Save neighbour right lane points
            for point in self.neighbour_right_lane_points:
                writer.writerow(["Neighbour Right", point[0], point[1]])

        self.get_logger().info(f"Lane points saved to {file_name}")


    def publish_map(self):
        """Publish the updated map as an OccupancyGrid message."""
        occupancy_grid_msg = OccupancyGrid()
        occupancy_grid_msg.header = Header()
        occupancy_grid_msg.header.stamp = self.get_clock().now().to_msg()
        occupancy_grid_msg.header.frame_id = "map"
        occupancy_grid_msg.info.resolution = self.map_resolution
        occupancy_grid_msg.info.width = self.map_width
        occupancy_grid_msg.info.height = self.map_height
        occupancy_grid_msg.info.origin.position.x = -self.map_width // 2 * self.map_resolution
        occupancy_grid_msg.info.origin.position.y = -self.map_height // 2 * self.map_resolution
        occupancy_grid_msg.data = self.occupancy_grid.flatten().tolist()
        self.map_pub.publish(occupancy_grid_msg)


def main(args=None):
    rclpy.init(args=args)
    dynamic_map_node = DynamicMapNode()
    rclpy.spin(dynamic_map_node)
    dynamic_map_node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

import numpy as np
import rclpy
from rclpy.node import Node
from nav_msgs.msg import OccupancyGrid
from std_msgs.msg import Header, Float32MultiArray
import tf2_ros
from tf2_ros import TransformListener, Buffer
import tf_transformations
from rclpy.qos import QoSProfile, DurabilityPolicy

class DynamicMapNode(Node):
    def __init__(self):
        super().__init__('dynamic_map_node')

        # Occupancy grid parameters
        qos_profile = QoSProfile(depth=10, durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.map_resolution = 0.01  # Resolution in meters per cell
        self.map_width = int(15.0 / self.map_resolution)  # 20 meters
        self.map_height = int(10.0 / self.map_resolution)  # 20 meters
        self.occupancy_grid = np.full((self.map_height, self.map_width), -1, dtype=np.int8)

        # Publisher for the occupancy grid
        self.map_pub = self.create_publisher(OccupancyGrid, '/map', qos_profile)

        # TF listener to track the car's position and orientation
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Timer to update the map
        self.create_timer(0.5, self.update_map)

        # Lane points storage
        self.left_lane_points = [(2, 0.4), (4, 0.4), (6, 0.4)]
        self.right_lane_points = [(2, -0.4), (4, -0.4), (6, -0.4)]

        # Subscriptions for lane points
        # self.left_lane_sub = self.create_subscription(Float32MultiArray, "left_lane_points", self.left_lane_callback, 10)
        # self.right_lane_sub = self.create_subscription(Float32MultiArray, "right_lane_points", self.right_lane_callback, 10)

        self.camera_offset_x = 1.3

        self.camera_offset_y = -1.45

        

        
    def left_lane_callback(self, msg):
        """Callback to receive left lane points."""
        # Extract the points from the message (pair of x, y)
        self.left_lane_points = np.array(msg.data).reshape(-1, 2)  # Reshape to pairs of points (x, y)
        self.get_logger().info(f"Received left lane points: {self.left_lane_points}")

    def right_lane_callback(self, msg):
        """Callback to receive right lane points."""
        # Extract the points from the message (pair of x, y)
        self.right_lane_points = np.array(msg.data).reshape(-1, 2)  # Reshape to pairs of points (x, y)
        self.get_logger().info(f"Received right lane points: {self.right_lane_points}")

    def update_map(self):
        try:
            # Get the latest transform from map to base_link
            transform = self.tf_buffer.lookup_transform('map', 'base_link', rclpy.time.Time())
            car_x = transform.transform.translation.x
            car_y = transform.transform.translation.y

            # Convert orientation to yaw angle
            rotation_quat = [
                transform.transform.rotation.x,
                transform.transform.rotation.y,
                transform.transform.rotation.z,
                transform.transform.rotation.w
            ]
            _, _, car_yaw = tf_transformations.euler_from_quaternion(rotation_quat)
            self.get_logger().info(f"Car position: ({car_x}, {car_y}), yaw: {car_yaw}")

            # Plot polylines based on the car's position and orientation
            if len(self.left_lane_points) > 0:
                self.plot_polyline(car_x, car_y, car_yaw, self.left_lane_points)
            if len(self.right_lane_points) > 0:
                self.plot_polyline(car_x, car_y, car_yaw, self.right_lane_points)

            # Publish the updated map
            self.publish_map()

        except Exception as e:
            self.get_logger().warn(f"Could not get transform: {e}")

    def plot_polyline(self, car_x, car_y, car_yaw, points):
        """Plots a polyline on the map by fitting a 2nd-degree polynomial through the given points."""
        # Extract x and y components from the points list
        px = np.array([p[1] + self.camera_offset_x for p in points])   # X coordinates of the lane points
        py = np.array([p[0] + self.camera_offset_y for p in points])   # Y coordinates of the lane points

        # Fit a 2nd-degree polynomial to the points
        poly_coeff = np.polyfit(px, py, 2)
        poly_func = np.poly1d(poly_coeff)

        # Sample points along the polynomial within the range of x-values in `px`
        x_samples = np.linspace(px.min(), px.max(), num=50)
        y_samples = poly_func(x_samples)

        # Rotate the polyline points based on the car's yaw angle
        rotated_points = []
        for sx, sy in zip(x_samples, y_samples):
            # Apply car's rotation and translation
            rotated_x = car_x + sx * np.cos(car_yaw) - sy * np.sin(car_yaw)
            rotated_y = car_y + sx * np.sin(car_yaw) + sy * np.cos(car_yaw)
            rotated_points.append((rotated_x, rotated_y))

        # Map rotated points onto the occupancy grid
        for rotated_x, rotated_y in rotated_points:
            # Convert to map grid coordinates
            grid_x = int((rotated_x / self.map_resolution) + self.map_width // 2)
            grid_y = int((rotated_y / self.map_resolution) + self.map_height // 2)

            # Ensure the coordinates are within the map bounds
            if 0 <= grid_x < self.map_width and 0 <= grid_y < self.map_height:
                self.occupancy_grid[grid_y, grid_x] = 100  # Mark as occupied

        self.get_logger().info(f"Car was at ({car_x}, {car_y}), yaw: {car_yaw}")
        self.get_logger().info(f"Plotting rotated polyline on the grid.")

        

    def publish_map(self):
        """Publish the updated map as an OccupancyGrid message."""
        occupancy_grid_msg = OccupancyGrid()
        occupancy_grid_msg.header = Header()
        occupancy_grid_msg.header.stamp = self.get_clock().now().to_msg()
        occupancy_grid_msg.header.frame_id = "map"
        occupancy_grid_msg.info.resolution = self.map_resolution
        occupancy_grid_msg.info.width = self.map_width
        occupancy_grid_msg.info.height = self.map_height
        occupancy_grid_msg.info.origin.position.x = -self.map_width // 2 * self.map_resolution
        occupancy_grid_msg.info.origin.position.y = -self.map_height // 2 * self.map_resolution
        occupancy_grid_msg.data = self.occupancy_grid.flatten().tolist()
        self.map_pub.publish(occupancy_grid_msg)


def main(args=None):
    rclpy.init(args=args)
    dynamic_map_node = DynamicMapNode()
    rclpy.spin(dynamic_map_node)
    dynamic_map_node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()

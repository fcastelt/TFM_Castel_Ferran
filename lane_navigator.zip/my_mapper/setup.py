from setuptools import find_packages, setup

package_name = 'my_mapper'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='ubuntu',
    maintainer_email='ferran.castel-turegano@arrk-engineering.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            "depth_to_laserscan = my_mapper.depth_to_laserscan:main",
            "dummy_point_mapper = my_mapper.dummy_point_mapper:main",
            "lane_point_mapper = my_mapper.lane_point_mapper:main",
            "multithread_lane_mapper = my_mapper.multithread_lane_mapper:main",
            "map_to_odom = my_mapper.map_to_odom:main",
            "navigate_map = my_mapper.navigate_map:main"  ,
            "subscriber_lane_points = my_mapper.subscriber_lane_points:main",
            "new_multithread_point_mapper = my_mapper.new_multithread_point_mapper:main",
            "odom_printer = my_mapper.odom_printer:main",
            "navigate_map_through_poses = my_mapper.navigate_map_through_poses:main",
            "lidar_trigger = my_mapper.lidar_trigger:main"
        ],
    },
)

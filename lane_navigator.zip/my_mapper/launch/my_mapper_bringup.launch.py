from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    # Get the share directory of the current package (replace 'your_package' with the actual package name)
    package_share_dir = get_package_share_directory('my_nav2_bringup')

    # Path to the navigation2 params file in the current package's params subfolder
    nav2_params_file = os.path.join(
        package_share_dir, 'params', 'nav2_params.yaml'
    )

    # Include the navigation launch file from nav2_bringup package
    nav2_bringup_share_dir = get_package_share_directory('nav2_bringup')
    nav2_bringup = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(nav2_bringup_share_dir, 'launch', 'navigation_launch.py')
        ),
        launch_arguments={'params_file': nav2_params_file}.items()
    )

    return LaunchDescription([
        # Reset car node
        Node(
            package='lateral_control',
            executable='reset_car',
            name='reset_car',
            output='screen'
        ),
        # Map to odom node
        Node(
            package='my_mapper',
            executable='map_to_odom',
            name='map_to_odom',
            output='screen'
        ),
        # Dummy point mapper node
        Node(
            package='my_mapper',
            executable='lane_point_mapper',
            name='lane_point_mapper',
            output='screen'
        ),
        # Navigate map node
        Node(
            package='my_mapper',
            executable='navigate_map',
            name='navigate_map',
            output='screen'
        ),
        # Include navigation2 launch
        #nav2_bringup,
    ])
